
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superiortnt.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.superiortnt.block.TranscendentTNTBlock;
import net.mcreator.superiortnt.block.SuperiorOreBlock;
import net.mcreator.superiortnt.block.GoodTNTBlock;
import net.mcreator.superiortnt.SuperiorTntMod;

public class SuperiorTntModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, SuperiorTntMod.MODID);
	public static final RegistryObject<Block> TRANSCENDENT_TNT = REGISTRY.register("transcendent_tnt", () -> new TranscendentTNTBlock());
	public static final RegistryObject<Block> SUPERIOR_ORE = REGISTRY.register("superior_ore", () -> new SuperiorOreBlock());
	public static final RegistryObject<Block> GOOD_TNT = REGISTRY.register("good_tnt", () -> new GoodTNTBlock());
}
