package net.mcreator.superiortnt.procedures;

public class GetTypeProcedure {
	public static void execute() {
	}
}
