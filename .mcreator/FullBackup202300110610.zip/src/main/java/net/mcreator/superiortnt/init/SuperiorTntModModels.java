
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superiortnt.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.superiortnt.client.model.Modelwide75tnt;
import net.mcreator.superiortnt.client.model.Modelwide100tnt;
import net.mcreator.superiortnt.client.model.ModelTNT_model;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class SuperiorTntModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modelwide100tnt.LAYER_LOCATION, Modelwide100tnt::createBodyLayer);
		event.registerLayerDefinition(Modelwide75tnt.LAYER_LOCATION, Modelwide75tnt::createBodyLayer);
		event.registerLayerDefinition(ModelTNT_model.LAYER_LOCATION, ModelTNT_model::createBodyLayer);
	}
}
