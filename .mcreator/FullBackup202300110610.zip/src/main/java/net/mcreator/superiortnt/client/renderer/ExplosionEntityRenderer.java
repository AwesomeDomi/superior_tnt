
package net.mcreator.superiortnt.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.superiortnt.entity.ExplosionEntityEntity;
import net.mcreator.superiortnt.client.model.ModelTNT_model;

public class ExplosionEntityRenderer extends MobRenderer<ExplosionEntityEntity, ModelTNT_model<ExplosionEntityEntity>> {
	public ExplosionEntityRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelTNT_model(context.bakeLayer(ModelTNT_model.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(ExplosionEntityEntity entity) {
		return new ResourceLocation("superior_tnt:textures/entities/hd_transparent_picture.png");
	}
}
