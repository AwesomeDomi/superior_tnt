
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superiortnt.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.superiortnt.entity.PrimedTranscendentTNTEntity;
import net.mcreator.superiortnt.entity.PrimedGoodTNTEntity;
import net.mcreator.superiortnt.entity.ExplosionEntityEntity;
import net.mcreator.superiortnt.SuperiorTntMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SuperiorTntModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SuperiorTntMod.MODID);
	public static final RegistryObject<EntityType<PrimedGoodTNTEntity>> PRIMED_GOOD_TNT = register("primed_good_tnt", EntityType.Builder.<PrimedGoodTNTEntity>of(PrimedGoodTNTEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PrimedGoodTNTEntity::new).fireImmune().sized(1f, 1f));
	public static final RegistryObject<EntityType<ExplosionEntityEntity>> EXPLOSION_ENTITY = register("explosion_entity", EntityType.Builder.<ExplosionEntityEntity>of(ExplosionEntityEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(0).setUpdateInterval(3).setCustomClientFactory(ExplosionEntityEntity::new).fireImmune().sized(0.1f, 0.1f));
	public static final RegistryObject<EntityType<PrimedTranscendentTNTEntity>> PRIMED_TRANSCENDENT_TNT = register("primed_transcendent_tnt", EntityType.Builder.<PrimedTranscendentTNTEntity>of(PrimedTranscendentTNTEntity::new, MobCategory.CREATURE)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(PrimedTranscendentTNTEntity::new).fireImmune().sized(40f, 100f));

	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			PrimedGoodTNTEntity.init();
			ExplosionEntityEntity.init();
			PrimedTranscendentTNTEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(PRIMED_GOOD_TNT.get(), PrimedGoodTNTEntity.createAttributes().build());
		event.put(EXPLOSION_ENTITY.get(), ExplosionEntityEntity.createAttributes().build());
		event.put(PRIMED_TRANSCENDENT_TNT.get(), PrimedTranscendentTNTEntity.createAttributes().build());
	}
}
