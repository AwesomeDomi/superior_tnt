package net.mcreator.superiortnt.procedures;

import net.minecraftforge.server.ServerLifecycleHooks;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import net.mcreator.superiortnt.network.SuperiorTntModVariables;
import net.mcreator.superiortnt.SuperiorTntMod;

public class TranscendentTNTMainProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTExplosionWidth = 4100;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTCylinderHeight = 1600;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTEllipsoidHeight = 432;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepHeight = 8;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepWidth = 4;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.tnt.primed")),
						SoundSource.NEUTRAL, 1, 1);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.tnt.primed")), SoundSource.NEUTRAL,
						1, 1, false);
			}
		}
		SuperiorTntMod.queueServerWork(100, () -> {
			if (!world.isClientSide()) {
				MinecraftServer _mcserv = ServerLifecycleHooks.getCurrentServer();
				if (_mcserv != null)
					_mcserv.getPlayerList().broadcastSystemMessage(Component.literal(
							"You actually ignited this?? Well, say goodbye to everything around you! P.S. This will most likely take a few hours."),
							false);
			}
			MainLinkProcedure.execute(world, x, y, z);
		});
	}
}
