package net.mcreator.superiortnt.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.superiortnt.network.SuperiorTntModVariables;

public class HeightCheckProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double height = 0;
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepAmount = 0;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		height = y - (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTCylinderHeight
				+ SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTEllipsoidHeight);
		while ((world.getBlockState(new BlockPos(x, height, z))).getBlock() == Blocks.AIR) {
			height = height + 1;
		}
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTMinHeight = height;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		while (!((world.getBlockState(new BlockPos(x, height, z))).getBlock() == Blocks.AIR)) {
			height = height + SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepHeight;
			SuperiorTntModVariables.WorldVariables
					.get(world).SuperiorTNTStepAmount = SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepAmount + 1;
			SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		}
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTMaxHeight = height;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
	}
}
