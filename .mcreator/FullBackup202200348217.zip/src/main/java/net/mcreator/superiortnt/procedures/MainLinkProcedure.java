package net.mcreator.superiortnt.procedures;

import net.minecraftforge.server.ServerLifecycleHooks;
import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.MinecraftServer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;

import net.mcreator.superiortnt.network.SuperiorTntModVariables;
import net.mcreator.superiortnt.SuperiorTntMod;

public class MainLinkProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double timer = 0;
		if (world instanceof Level _level) {
			if (!_level.isClientSide()) {
				_level.playSound(null, new BlockPos(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")),
						SoundSource.NEUTRAL, 1, 1);
			} else {
				_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.explode")),
						SoundSource.NEUTRAL, 1, 1, false);
			}
		}
		HeightCheckProcedure.execute(world, x, y, z);
		timer = 1;
		SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTPercentage = 0;
		SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
		for (int index0 = 0; index0 < (int) (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepAmount); index0++) {
			for (int index1 = 0; index1 < (int) (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTWidthAmount); index1++) {
				SuperiorTntMod.queueServerWork((int) timer, () -> {
					CylinderPartProcedure.execute(world, x, z);
				});
				timer = timer + 1;
			}
			timer = timer + 20;
			SuperiorTntMod.queueServerWork((int) timer, () -> {
				SuperiorTntModVariables.WorldVariables
						.get(world).SuperiorTNTPercentage = SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTPercentage + 1;
				SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
				if (!world.isClientSide()) {
					MinecraftServer _mcserv = ServerLifecycleHooks.getCurrentServer();
					if (_mcserv != null)
						_mcserv.getPlayerList()
								.broadcastSystemMessage(
										Component
												.literal(("Explosion "
														+ (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTPercentage * 100)
																/ SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepAmount
														+ "% complete!")),
										false);
				}
			});
			timer = timer + 20;
		}
	}
}
