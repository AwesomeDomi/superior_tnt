package net.mcreator.superiortnt.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.superiortnt.network.SuperiorTntModVariables;

public class CylinderPartProcedure {
	public static void execute(LevelAccessor world, double x, double z) {
		double j = 0;
		double k = 0;
		double dx = 0;
		double dz = 0;
		double ExplosionWidthSquared = 0;
		ExplosionWidthSquared = Math.pow(SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTExplosionWidth, 2);
		if (world instanceof ServerLevel _origLevel) {
			LevelAccessor _worldorig = world;
			world = _origLevel.getServer().getLevel(Level.OVERWORLD);
			if (world != null) {
				for (int index0 = 0; index0 < (int) (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepWidth); index0++) {
					k = z - SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTExplosionWidth + 1;
					for (int index1 = 0; index1 < (int) (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTExplosionWidth * 2
							- 1); index1++) {
						dx = Math.abs(SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTTempWidth - x);
						dz = Math.abs(k - z);
						if (dx * dx + dz * dz < ExplosionWidthSquared) {
							j = SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTTempHeight;
							for (int index2 = 0; index2 < (int) (SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTStepHeight); index2++) {
								if (!((world
										.getBlockState(new BlockPos(SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTTempWidth, j, k)))
										.getBlock() == Blocks.AIR)) {
									world.setBlock(new BlockPos(SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTTempWidth, j, k),
											Blocks.AIR.defaultBlockState(), 3);
									SuperiorTntModVariables.WorldVariables
											.get(world).SuperiorTNTBlocksDestroyed = SuperiorTntModVariables.WorldVariables
													.get(world).SuperiorTNTBlocksDestroyed + 1;
									SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
								}
								j = j - 1;
							}
						}
						k = k + 1;
					}
					SuperiorTntModVariables.WorldVariables
							.get(world).SuperiorTNTTempWidth = SuperiorTntModVariables.WorldVariables.get(world).SuperiorTNTTempWidth + 1;
					SuperiorTntModVariables.WorldVariables.get(world).syncData(world);
				}
			}
			world = _worldorig;
		}
	}
}
