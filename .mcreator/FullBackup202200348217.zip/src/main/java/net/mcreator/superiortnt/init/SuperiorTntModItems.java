
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superiortnt.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.superiortnt.SuperiorTntMod;

public class SuperiorTntModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, SuperiorTntMod.MODID);
	public static final RegistryObject<Item> TRANSCENDENT_TNT = block(SuperiorTntModBlocks.TRANSCENDENT_TNT, SuperiorTntModTabs.TAB_SUPERIOR_TNT);
	public static final RegistryObject<Item> PRIMED_GOOD_TNT = REGISTRY.register("primed_good_tnt_spawn_egg",
			() -> new ForgeSpawnEggItem(SuperiorTntModEntities.PRIMED_GOOD_TNT, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC)));

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
