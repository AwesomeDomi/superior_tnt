
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.superiortnt.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.superiortnt.client.renderer.PrimedTranscendentTNTRenderer;
import net.mcreator.superiortnt.client.renderer.PrimedGoodTNTRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SuperiorTntModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(SuperiorTntModEntities.PRIMED_TRANSCENDENT_TNT.get(), PrimedTranscendentTNTRenderer::new);
		event.registerEntityRenderer(SuperiorTntModEntities.PRIMED_GOOD_TNT.get(), PrimedGoodTNTRenderer::new);
	}
}
